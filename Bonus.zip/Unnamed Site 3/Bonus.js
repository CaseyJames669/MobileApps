/**
 * 
 */
<html>
<body>

<script>

document.write("<h1>This is a heading</h1>");


</script>

</body>
</html>